# Workspace setup

## Human (do this first)

From the machine that already has the kit:

```bash
cp -R /path/to/.agents/setup/. /path/to/new-workspace/
```

The trailing `/.` matters. It copies hidden `.agents` and `.gitignore`. Open the new workspace root in the agent host. Paste this whole file as the first message.

---

## Agent

Read root `AGENTS.md`, then this file. This task is already approved. Mode is vibe. Do not enter Align. Do not ask whether to Spec. Fill the templates from disk. Ask at most one question, and only if verify commands or local policy cannot be read from the repos.

This is a multi-repo knowledge workspace, same shape as the kit source. Child folders are independent git repositories. The kernel is already at `AGENTS.md`. Skills are already under `.agents/skills/`. Do not copy MEMORY, plans, or a repository index from any other machine.

### Do

1. Confirm the kit landed: `AGENTS.md`, `.gitignore`, `.agents/AGENTS.md`, `.agents/MEMORY.md`, `.agents/WORKSPACE.md`, `.agents/skills/`, `run/dev/`, `run/test/`. If something is missing, say what and stop.

2. Rewrite `.agents/WORKSPACE.md` from this tree. Replace placeholders. Do not leave the "setup agent fills" sentence.
   - Layout paths for this machine (workspace root, not `~/Github`).
   - Verify commands from child `AGENTS.md`, `package.json`, `test.sh`, or README. If unknown after a scan, ask once.
   - Keep the visual-QA local policy unless the user already stated a different rule.
   - Repository index: one bullet per child git repo or obvious product pair. Short, factual. No marketing.
   - Shared pattern family only if siblings share a template or package. Otherwise omit that section.

3. Rewrite `.agents/MEMORY.md` `## Orientation` with this tree only: layout pointer at WORKSPACE.md, how to verify, where project memory lives. Leave `## Quirks` empty unless you hit a real coupling while setting up.

4. For each child directory that is its own git repo:
   - Create `.agents/projects/<dir>/AGENTS.md` from `.agents/templates/project-AGENTS.md` (replace `<project>` and `<slug>`).
   - Create `.agents/projects/<dir>/MEMORY.md` from `.agents/templates/project-MEMORY.md`. Fill verify if you found it. Do not invent quirks.
   - In the child repo, add a slashless `.agents` line to `.gitignore` if missing (`.agents` matches the symlink; `.agents/` does not).
   - If the child has no `.agents` path yet, `ln -s ../.agents/projects/<dir> .agents` from the child root.
   - Do not overwrite a live child `.agents` directory that is not this symlink (example: a project that keeps its own `.agents`). Report it and skip.

5. Leave `run/dev/` and `run/test/` in place. Do not invent launcher scripts unless a child already documents a one-liner you can copy. Empty dirs are fine.

6. Leave skills as they are. Do not add skills. Do not run skill installers.

7. Move this file to `.agents/docs/SETUP.md` when the steps above are done so the workspace root stays the kernel plus gitignore. Delete `README.md` from the workspace root if it came from the kit.

8. Do not stage, commit, or push.

### Do not

- Do not write product code.
- Do not copy another workspace's MEMORY, plan history, or repo list.
- Do not create `.agents/projects/` entries for folders that are not git repos.
- Do not open a browser.

### Done when

- Root `AGENTS.md` is still the kernel (no repo index inside it).
- `.agents/WORKSPACE.md` names this tree's children and verify commands.
- Each child git repo that you linked has `.agents` -> `../.agents/projects/<dir>` and a slashless `.agents` gitignore entry.
- You report what you linked, what you skipped, and what you could not verify.
