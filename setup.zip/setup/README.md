# Copy this folder's contents to a new multi-repo workspace

```bash
cp -R /path/to/.agents/setup/. /path/to/new-workspace/
```

The trailing `/.` copies hidden `.agents` and `.gitignore`.

Then open the new workspace in the agent host and paste `SETUP.md` as the first message. The agent fills WORKSPACE.md, MEMORY.md, and per-project `.agents` links.

Do not copy live `MEMORY.md`, `plan/`, or `projects/` from the source machine. Those are not in this kit.
