/**
 * Classifies units and assigns slop archetypes, health scores, and remediation advice.
 * @param {Array<object>} units - List of parsed units with git churn
 * @param {Map<string, Set<string>>} inboundMap - Map of unitId -> Set of parent unitIds rendering/calling it
 * @returns {Array<object>} - Enriched units with slop metrics
 */
export function classifySlop(units, inboundMap) {
  return units.map((u) => {
    const churn = u.git?.commitCount || 0;
    const cyclomatic = u.cyclomatic || 1;
    const totalLoc = u.totalLoc || 1;
    const propsCount = u.props?.length || 0;
    const composablesCount = u.composables?.length || 0;
    const childrenCount = u.renderedChildren?.length || 0;
    const inbounds = inboundMap.get(u.id)?.size || 0;

    // Hotspot formula: Churn factor * Complexity factor * Size factor
    // Normalized score 0 - 100
    const churnFactor = Math.min(churn * 3.5, 40);
    const complexityFactor = Math.min(cyclomatic * 1.8, 35);
    const sizeFactor = Math.min((totalLoc / 400) * 25, 25);

    const slopScore = Math.min(Math.round(churnFactor + complexityFactor + sizeFactor), 100);

    const flags = [];
    const recommendations = [];

    // 1. Critical Hotspot
    if (churn >= 8 && cyclomatic >= 12) {
      flags.push({
        type: "CRITICAL_HOTSPOT",
        label: "Critical Hotspot",
        severity: "critical",
        icon: "🔥",
        description: `High churn (${churn} commits) coupled with high cyclomatic complexity (${cyclomatic}). Prime candidate for bugs.`,
      });
      recommendations.push("Break into smaller single-responsibility sub-modules to reduce frequent edit collisions.");
    }

    // 2. God Unit
    if (totalLoc > 320 && (propsCount > 7 || composablesCount >= 5 || cyclomatic > 18)) {
      flags.push({
        type: "GOD_UNIT",
        label: u.category === "frontend" ? "God Component" : "God Module",
        severity: "critical",
        icon: "🏛️",
        description: `Massive file (${totalLoc} LOC) doing too much with ${propsCount} props/methods and ${composablesCount} dependencies.`,
      });
      recommendations.push("Extract stateful logic into dedicated composables or service layers, and decompose templates.");
    }

    // 3. Composable / Service Spaghetti
    if (composablesCount >= 6) {
      flags.push({
        type: "SPAGHETTI_DEPENDENCIES",
        label: "Spaghetti Coupling",
        severity: "warning",
        icon: "🪢",
        description: `Glues ${composablesCount} external hooks/dependencies directly in one file. Leaky abstraction.`,
      });
      recommendations.push("Introduce a domain facade or controller composable to hide internal hook orchestration.");
    }

    // 4. Prop Drill Hub
    if (u.category === "frontend" && propsCount >= 9 && childrenCount >= 3) {
      flags.push({
        type: "PROP_DRILLER",
        label: "Prop Drill Hub",
        severity: "warning",
        icon: "🧱",
        description: `Accepts ${propsCount} props while rendering ${childrenCount} child components. High risk of prop drilling.`,
      });
      recommendations.push("Evaluate slot composition (<slot />) or context/provide-inject to bypass intermediate props pass-through.");
    }

    // 5. Orphan Unit (potential dead code)
    const isRoot = u.atomicTier === "page" || u.relPath.includes("/pages/") || u.relPath.includes("main.") || u.relPath.includes("App.") || u.relPath.includes("index.");
    if (!isRoot && inbounds === 0 && childrenCount === 0 && churn < 2) {
      flags.push({
        type: "ORPHAN",
        label: "Orphan Unit",
        severity: "info",
        icon: "👻",
        description: "0 inbound callers/renderers detected in scanned scope. Potential dead code.",
      });
      recommendations.push("Verify if still used or clean up dead component code.");
    }

    // 6. Shallow Pass-Through Module
    if (propsCount >= 8 && totalLoc < 45 && cyclomatic <= 2) {
      flags.push({
        type: "SHALLOW_MODULE",
        label: "Shallow Module",
        severity: "warning",
        icon: "🪶",
        description: `Wide interface (${propsCount} exports/props) with only ${totalLoc} LOC. Violates deep module leverage.`,
      });
      recommendations.push("Consider inline composition or deepening the implementation to justify the surface area.");
    }

    // Determine status badge & color
    let status = "healthy";
    let accentColor = "#10b981"; // green
    if (flags.some((f) => f.severity === "critical")) {
      status = "critical";
      accentColor = "#ef4444"; // red
    } else if (flags.some((f) => f.severity === "warning")) {
      status = "warning";
      accentColor = "#f59e0b"; // orange
    } else if (flags.some((f) => f.severity === "info")) {
      status = "info";
      accentColor = "#64748b"; // muted slate
    } else if (u.atomicTier === "atom") {
      accentColor = "#3b82f6"; // blue
    }

    return {
      ...u,
      slopScore,
      status,
      accentColor,
      flags,
      recommendations: recommendations.length > 0 ? recommendations : ["Component is stable and well-bounded."],
      inboundCount: inbounds,
    };
  });
}
