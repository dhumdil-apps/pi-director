#!/usr/bin/env node
import { runSlopRadar } from "./scan.mjs";
const targetDir = process.argv[2] || process.cwd();
runSlopRadar({ dir: targetDir, filterType: "astro", title: "Astro Component Architecture & Slop Radar" });
