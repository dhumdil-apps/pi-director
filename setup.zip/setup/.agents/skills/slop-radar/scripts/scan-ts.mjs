#!/usr/bin/env node
import { runSlopRadar } from "./scan.mjs";
const targetDir = process.argv[2] || process.cwd();
runSlopRadar({ dir: targetDir, filterType: "ts", title: "TypeScript Architecture & Slop Radar" });
