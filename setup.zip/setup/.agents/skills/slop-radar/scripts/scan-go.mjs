#!/usr/bin/env node
import { runSlopRadar } from "./scan.mjs";
const targetDir = process.argv[2] || process.cwd();
runSlopRadar({ dir: targetDir, filterType: "go", title: "Go Backend Architecture & Slop Radar" });
