import fs from "node:fs";
import path from "node:path";

/**
 * Deterministic Go module extractor.
 */
export function extractGoUnit(filePath, rootDir) {
  const content = fs.readFileSync(filePath, "utf-8");
  const fileName = path.basename(filePath);
  const relPath = path.relative(rootDir, filePath);
  const lines = content.split("\n");
  const totalLoc = lines.length;
  const cleanLoc = lines.filter((l) => l.trim().length > 0 && !l.trim().startsWith("//")).length;

  // 1. Package name
  const pkgMatch = content.match(/^package\s+([a-zA-Z0-9_]+)/m);
  const pkgName = pkgMatch ? pkgMatch[1] : "main";

  // 2. Structs & Interfaces
  const structsOrClasses = [];
  const structMatches = content.matchAll(/type\s+([A-Za-z0-9_]+)\s+(struct|interface)/g);
  for (const sm of structMatches) {
    structsOrClasses.push({ name: sm[1], kind: sm[2] });
  }

  // 3. Exported functions & methods
  const exportedMethods = [];
  const funcMatches = content.matchAll(/func\s+(?:\([^\)]+\)\s+)?([A-Z][a-zA-Z0-9_]*)\s*\(/g);
  for (const fm of funcMatches) {
    exportedMethods.push(fm[1]);
  }

  // 4. Internal dependencies & imports
  const dependencies = new Set();
  const importMatches = content.matchAll(/["']([^"']+)["']/g);
  for (const im of importMatches) {
    const imp = im[1];
    if (imp.includes("/") && !imp.startsWith("fmt") && !imp.startsWith("net/http") && !imp.startsWith("os") && !imp.startsWith("time")) {
      const lastPart = imp.split("/").pop();
      if (lastPart) dependencies.add(lastPart);
    }
  }

  // 5. Unit classification
  let unitType = "package";
  if (relPath.includes("handler") || fileName.includes("handler") || content.includes("echo.Context") || content.includes("http.ResponseWriter")) {
    unitType = "handler";
  } else if (relPath.includes("service") || fileName.includes("service") || relPath.includes("usecase")) {
    unitType = "service";
  } else if (relPath.includes("repository") || relPath.includes("repo") || relPath.includes("store") || relPath.includes("db")) {
    unitType = "repository";
  } else if (relPath.includes("middleware")) {
    unitType = "middleware";
  } else if (relPath.includes("model") || relPath.includes("schema") || relPath.includes("entity")) {
    unitType = "model";
  }

  // 6. Cyclomatic complexity
  let cyclomatic = 1;
  cyclomatic += (content.match(/\b(if|for|switch|select|case)\b/g) || []).length;
  cyclomatic += (content.match(/\berr\s*!=\s*nil\b/g) || []).length;

  const baseName = fileName.replace(/\.[^/.]+$/, "");

  return {
    id: baseName,
    name: fileName,
    filePath,
    relPath,
    category: "backend",
    framework: "go",
    unitType,
    atomicTier: unitType,
    totalLoc,
    scriptLoc: cleanLoc,
    templateLoc: 0,
    styleLoc: 0,
    props: exportedMethods,
    emits: [],
    slots: [],
    composables: Array.from(dependencies),
    stores: [],
    refsCount: structsOrClasses.length,
    renderedChildren: Array.from(dependencies),
    cyclomatic,
  };
}
