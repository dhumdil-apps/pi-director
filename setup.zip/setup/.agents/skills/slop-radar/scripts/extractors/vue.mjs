import fs from "node:fs";
import path from "node:path";

/**
 * Deterministic Vue 3 SFC extractor.
 * Parses <script setup>, <script>, <template>, and <style> blocks.
 */
export function extractVueUnit(filePath, rootDir) {
  const content = fs.readFileSync(filePath, "utf-8");
  const fileName = path.basename(filePath);
  const relPath = path.relative(rootDir, filePath);
  const totalLoc = content.split("\n").length;

  const scriptMatches = content.match(/<script[\s\S]*?>([\s\S]*?)<\/script>/gi) || [];
  const scriptContent = scriptMatches.map((s) => s.replace(/<\/?script[\s\S]*?>/gi, "")).join("\n");

  const templateMatch = content.match(/<template[\s\S]*?>([\s\S]*?)<\/template>/i);
  const templateContent = templateMatch ? templateMatch[1] : "";

  const styleMatches = content.match(/<style[\s\S]*?>([\s\S]*?)<\/style>/gi) || [];
  const styleContent = styleMatches.map((s) => s.replace(/<\/?style[\s\S]*?>/gi, "")).join("\n");

  const scriptLoc = scriptContent.split("\n").filter((l) => l.trim().length > 0).length;
  const templateLoc = templateContent.split("\n").filter((l) => l.trim().length > 0).length;
  const styleLoc = styleContent.split("\n").filter((l) => l.trim().length > 0).length;

  // 1. Props
  const props = new Set();
  const definePropsMatches = scriptContent.match(/defineProps\s*(?:<([\s\S]*?)>|\(([\s\S]*?)\))/);
  if (definePropsMatches) {
    const rawProps = definePropsMatches[1] || definePropsMatches[2] || "";
    const propKeys = rawProps.match(/([a-zA-Z0-9_$]+)\s*[?:=]/g) || [];
    for (const pk of propKeys) {
      props.add(pk.replace(/[?:=]/g, "").trim());
    }
  }

  // 2. Emits
  const emits = new Set();
  const defineEmitsMatches = scriptContent.match(/defineEmits\s*(?:<([\s\S]*?)>|\(([\s\S]*?)\))/);
  if (defineEmitsMatches) {
    const rawEmits = defineEmitsMatches[1] || defineEmitsMatches[2] || "";
    const emitKeys = rawEmits.match(/['"]([a-zA-Z0-9_-]+)['"]/g) || [];
    for (const ek of emitKeys) {
      emits.add(ek.replace(/['"]/g, "").trim());
    }
  }

  // 3. Slots
  const slots = new Set();
  const slotMatches = templateContent.match(/<slot(?:\s+name=['"]([^'"]+)['"])?/g) || [];
  for (const sm of slotMatches) {
    const nameMatch = sm.match(/name=['"]([^'"]+)['"]/);
    slots.add(nameMatch ? nameMatch[1] : "default");
  }

  // 4. Composables & Hooks (use*)
  const composables = new Set();
  const composableMatches = scriptContent.match(/\b(use[A-Z][a-zA-Z0-9_]*)\b/g) || [];
  for (const c of composableMatches) {
    composables.add(c);
  }

  // 5. Stores (Pinia/Nanostores)
  const stores = new Set();
  const storeMatches = scriptContent.match(/\b(use[A-Z][a-zA-Z0-9_]*Store|\$[a-zA-Z0-9_]+)\b/g) || [];
  for (const s of storeMatches) {
    stores.add(s);
  }

  // 6. Reactive states count
  const refsCount = (scriptContent.match(/\b(ref|reactive|shallowRef|computed|defineModel)\s*(?:<[^>]+>)?\(/g) || []).length;

  // 7. Child components rendered
  const renderedChildren = new Set();
  const tagMatches = templateContent.match(/<([A-Z][a-zA-Z0-9]+)[\s\/>]/g) || [];
  for (const tm of tagMatches) {
    const tag = tm.replace(/[<\s\/>]/g, "").trim();
    if (!["Fragment", "Transition", "KeepAlive", "Teleport", "Suspense"].includes(tag)) {
      renderedChildren.add(tag);
    }
  }

  // Kebab-case custom elements (e.g., tuto-button, pi-flow-canvas)
  const ceMatches = templateContent.match(/<([a-z0-9]+-[a-z0-9-]+)[\s\/>]/g) || [];
  for (const cm of ceMatches) {
    const tag = cm.replace(/[<\s\/>]/g, "").trim();
    renderedChildren.add(tag);
  }

  // Imported components
  const importMatches = scriptContent.match(/import\s+([A-Z][a-zA-Z0-9_]*)\s+from\s+['"][^'"]+\.vue['"]/g) || [];
  for (const im of importMatches) {
    const nameMatch = im.match(/import\s+([A-Z][a-zA-Z0-9_]*)/);
    if (nameMatch && nameMatch[1]) renderedChildren.add(nameMatch[1]);
  }

  // 8. Cyclomatic complexity
  let cyclomatic = 1;
  cyclomatic += (scriptContent.match(/\b(if|else if|case|for|while|catch)\b/g) || []).length;
  cyclomatic += (scriptContent.match(/(\?\s*[^:]+\s*:|\&\&|\|\||\?\.)/g) || []).length;
  cyclomatic += (templateContent.match(/\b(v-if|v-else-if|v-for)\b/g) || []).length;

  // 9. Atomic Tier
  let atomicTier = "molecule";
  if (relPath.includes("/atoms/") || fileName.includes("Button") || fileName.includes("Badge") || (templateLoc < 40 && props.size <= 4 && composables.size <= 1)) {
    atomicTier = "atom";
  } else if (relPath.includes("/pages/") || relPath.includes("/views/") || fileName.endsWith("Page.vue") || fileName.endsWith("View.vue")) {
    atomicTier = "page";
  } else if (relPath.includes("/layouts/") || fileName.includes("Layout") || slots.size >= 2) {
    atomicTier = "template";
  } else if (relPath.includes("/organisms/") || relPath.includes("/features/") || totalLoc > 200 || composables.size >= 3 || renderedChildren.size >= 3) {
    atomicTier = "organism";
  }

  const baseName = fileName.replace(/\.[^/.]+$/, "");

  return {
    id: baseName,
    name: fileName,
    filePath,
    relPath,
    category: "frontend",
    framework: "vue",
    unitType: "component",
    atomicTier,
    totalLoc,
    scriptLoc,
    templateLoc,
    styleLoc,
    props: Array.from(props),
    emits: Array.from(emits),
    slots: Array.from(slots),
    composables: Array.from(composables),
    stores: Array.from(stores),
    refsCount,
    renderedChildren: Array.from(renderedChildren),
    cyclomatic,
  };
}
