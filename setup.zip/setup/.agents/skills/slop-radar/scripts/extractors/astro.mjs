import fs from "node:fs";
import path from "node:path";

/**
 * Deterministic Astro extractor.
 * Parses frontmatter, slots, client island directives, and child components.
 */
export function extractAstroUnit(filePath, rootDir) {
  const content = fs.readFileSync(filePath, "utf-8");
  const fileName = path.basename(filePath);
  const relPath = path.relative(rootDir, filePath);
  const totalLoc = content.split("\n").length;

  const frontmatterMatch = content.match(/^---\s*([\s\S]*?)\s*---/);
  const scriptContent = frontmatterMatch ? frontmatterMatch[1] : "";
  const templateContent = content.replace(/^---\s*([\s\S]*?)\s*---/, "");

  const styleMatches = templateContent.match(/<style[\s\S]*?>([\s\S]*?)<\/style>/gi) || [];
  const styleContent = styleMatches.map((s) => s.replace(/<\/?style[\s\S]*?>/gi, "")).join("\n");

  const scriptLoc = scriptContent.split("\n").filter((l) => l.trim().length > 0).length;
  const templateLoc = templateContent.split("\n").filter((l) => l.trim().length > 0).length;
  const styleLoc = styleContent.split("\n").filter((l) => l.trim().length > 0).length;

  // 1. Props
  const props = new Set();
  const astroPropsMatch = scriptContent.match(/interface\s+Props\s*\{([\s\S]*?)\}/);
  if (astroPropsMatch) {
    const propKeys = astroPropsMatch[1].match(/([a-zA-Z0-9_$]+)\s*[?:]/g) || [];
    for (const pk of propKeys) {
      props.add(pk.replace(/[?:]/g, "").trim());
    }
  }
  const destructureMatch = scriptContent.match(/(?:const|let)\s*\{([^}]+)\}\s*=\s*Astro\.props/);
  if (destructureMatch) {
    const keys = destructureMatch[1].split(",").map((k) => k.trim().split(/[:=]/)[0].trim());
    keys.forEach((k) => { if (k) props.add(k); });
  }

  // 2. Slots
  const slots = new Set();
  const slotMatches = templateContent.match(/<slot(?:\s+name=['"]([^'"]+)['"])?/g) || [];
  for (const sm of slotMatches) {
    const nameMatch = sm.match(/name=['"]([^'"]+)['"]/);
    slots.add(nameMatch ? nameMatch[1] : "default");
  }

  // 3. Child Components & Client Islands
  const renderedChildren = new Set();
  const islands = new Set();

  const tagMatches = templateContent.match(/<([A-Z][a-zA-Z0-9]+)[\s\/>]/g) || [];
  for (const tm of tagMatches) {
    const tag = tm.replace(/[<\s\/>]/g, "").trim();
    if (!["Fragment"].includes(tag)) renderedChildren.add(tag);
  }

  const islandMatches = templateContent.matchAll(/<([A-Z][a-zA-Z0-9]+)[^>]*?(client:(?:load|visible|idle|only))/g);
  for (const im of islandMatches) {
    islands.add(`${im[1]} (${im[2]})`);
  }

  // 4. Cyclomatic complexity
  let cyclomatic = 1;
  cyclomatic += (scriptContent.match(/\b(if|else if|case|for|while)\b/g) || []).length;
  cyclomatic += (scriptContent.match(/(\?\s*[^:]+\s*:|\&\&|\|\||\?\.)/g) || []).length;
  cyclomatic += (templateContent.match(/\{[^}]*?\b(map|filter|forEach)\b/g) || []).length;

  let atomicTier = relPath.includes("/pages/") ? "page" : relPath.includes("/layouts/") ? "template" : "organism";

  const baseName = fileName.replace(/\.[^/.]+$/, "");

  return {
    id: baseName,
    name: fileName,
    filePath,
    relPath,
    category: "frontend",
    framework: "astro",
    unitType: "astro",
    atomicTier,
    totalLoc,
    scriptLoc,
    templateLoc,
    styleLoc,
    props: Array.from(props),
    emits: [],
    slots: Array.from(slots),
    composables: Array.from(islands),
    stores: [],
    refsCount: 0,
    renderedChildren: Array.from(renderedChildren),
    cyclomatic,
  };
}
