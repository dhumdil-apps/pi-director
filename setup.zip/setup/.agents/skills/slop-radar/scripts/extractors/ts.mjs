import fs from "node:fs";
import path from "node:path";

/**
 * Deterministic TypeScript / Web Component / Composable extractor.
 */
export function extractTsUnit(filePath, rootDir) {
  const content = fs.readFileSync(filePath, "utf-8");
  const fileName = path.basename(filePath);
  const relPath = path.relative(rootDir, filePath);
  const totalLoc = content.split("\n").length;
  const cleanLoc = content.split("\n").filter((l) => l.trim().length > 0 && !l.trim().startsWith("//")).length;

  let unitType = "module";
  if (fileName.startsWith("use") || relPath.includes("/composables/") || relPath.includes("/hooks/")) {
    unitType = "composable";
  } else if (relPath.includes("/stores/") || fileName.includes("Store") || fileName.includes("store")) {
    unitType = "store";
  } else if (content.includes("customElements.define") || content.includes("extends HTMLElement") || content.includes("extends BaseElement")) {
    unitType = "web-component";
  }

  // 1. Exported functions & methods (interface surface)
  const exportsList = new Set();
  const exportMatches = content.matchAll(/export\s+(?:async\s+)?(?:function|const|class|type|interface)\s+([a-zA-Z0-9_$]+)/g);
  for (const em of exportMatches) {
    exportsList.add(em[1]);
  }

  // 2. Used hooks & composables
  const composables = new Set();
  const hookMatches = content.matchAll(/\b(use[A-Z][a-zA-Z0-9_]*)\b/g);
  for (const hm of hookMatches) {
    if (hm[1] !== fileName.replace(/\.[^/.]+$/, "")) {
      composables.add(hm[1]);
    }
  }

  // 3. Rendered JSX tags if TSX/JSX
  const renderedChildren = new Set();
  const tagMatches = content.matchAll(/<([A-Z][a-zA-Z0-9]+)[\s\/>]/g);
  for (const tm of tagMatches) {
    if (!["Fragment"].includes(tm[1])) renderedChildren.add(tm[1]);
  }

  // 4. Cyclomatic complexity
  let cyclomatic = 1;
  cyclomatic += (content.match(/\b(if|else if|case|for|while|catch)\b/g) || []).length;
  cyclomatic += (content.match(/(\?\s*[^:]+\s*:|\&\&|\|\||\?\.)/g) || []).length;

  let atomicTier = unitType === "composable" ? "molecule" : unitType === "web-component" ? "atom" : "organism";

  const baseName = fileName.replace(/\.[^/.]+$/, "");

  return {
    id: baseName,
    name: fileName,
    filePath,
    relPath,
    category: "frontend",
    framework: "typescript",
    unitType,
    atomicTier,
    totalLoc,
    scriptLoc: cleanLoc,
    templateLoc: 0,
    styleLoc: 0,
    props: Array.from(exportsList),
    emits: [],
    slots: [],
    composables: Array.from(composables),
    stores: [],
    refsCount: 0,
    renderedChildren: Array.from(renderedChildren),
    cyclomatic,
  };
}
