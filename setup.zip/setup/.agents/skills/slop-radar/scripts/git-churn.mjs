import { execSync } from "node:child_process";
import { resolve, relative } from "node:path";

/**
 * Extracts git churn metrics for a file.
 * @param {string} filePath - Absolute path to file
 * @param {string} projectRoot - Git repository root
 * @returns {{ commitCount: number, recentCommits: string[], authors: string[], lastModified: string }}
 */
export function getGitChurn(filePath, projectRoot) {
  const relPath = relative(projectRoot, filePath);
  try {
    const raw = execSync(
      `git log --follow --format="%h|%an|%ad|%s" --date=short --since="6 months ago" -n 20 -- "${relPath}"`,
      {
        cwd: projectRoot,
        encoding: "utf-8",
        stdio: ["ignore", "pipe", "ignore"],
      }
    ).trim();

    if (!raw) {
      return { commitCount: 0, recentCommits: [], authors: [], lastModified: "Never/Untracked" };
    }

    const lines = raw.split("\n").filter(Boolean);
    const recentCommits = [];
    const authorSet = new Set();
    let lastModified = "";

    for (let i = 0; i < lines.length; i++) {
      const [hash, author, date, ...rest] = lines[i].split("|");
      const msg = rest.join("|");
      if (i === 0) lastModified = date || "";
      if (author) authorSet.add(author);
      recentCommits.push(`${date} [${hash}] ${msg} (${author})`);
    }

    return {
      commitCount: lines.length,
      recentCommits,
      authors: Array.from(authorSet),
      lastModified,
    };
  } catch {
    return { commitCount: 0, recentCommits: [], authors: [], lastModified: "Unknown" };
  }
}
