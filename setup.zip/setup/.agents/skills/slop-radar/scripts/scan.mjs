#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { extractVueUnit } from "./extractors/vue.mjs";
import { extractAstroUnit } from "./extractors/astro.mjs";
import { extractTsUnit } from "./extractors/ts.mjs";
import { extractGoUnit } from "./extractors/go.mjs";
import { getGitChurn } from "./git-churn.mjs";
import { classifySlop } from "./slop-classifier.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * Recursively scans directory for code files based on type filter.
 */
function crawlFiles(dir, filterType = "all", fileList = []) {
  if (!fs.existsSync(dir)) return fileList;
  const entries = fs.readdirSync(dir, { withFileTypes: true });

  const validExts = {
    vue: [".vue"],
    astro: [".astro"],
    ts: [".ts", ".tsx", ".js", ".jsx"],
    go: [".go"],
    all: [".vue", ".astro", ".tsx", ".jsx", ".ts", ".js", ".go"],
  }[filterType] || [".vue", ".astro", ".tsx", ".jsx", ".ts", ".js", ".go"];

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (
        entry.name === "node_modules" ||
        entry.name === ".git" ||
        entry.name === "dist" ||
        entry.name === ".astro" ||
        entry.name === ".pi" ||
        entry.name === "vendor" ||
        entry.name === "migrations" ||
        entry.name === ".turbo" ||
        entry.name === "coverage"
      ) {
        continue;
      }
      crawlFiles(fullPath, filterType, fileList);
    } else if (entry.isFile()) {
      if (
        entry.name.includes(".gen.") ||
        entry.name.includes(".generated.") ||
        entry.name.endsWith(".d.ts") ||
        entry.name.endsWith(".spec.ts") ||
        entry.name.endsWith(".test.ts") ||
        entry.name.endsWith("_test.go")
      ) {
        continue;
      }
      const ext = path.extname(entry.name).toLowerCase();
      if (validExts.includes(ext)) {
        fileList.push(fullPath);
      }
    }
  }
  return fileList;
}

/**
 * Main deterministic execution function.
 */
export async function runSlopRadar(options = {}) {
  const targetDir = path.resolve(options.dir || process.cwd());
  const projectRoot = options.root || targetDir;
  const filterType = options.filterType || "all";
  const projectName = options.title || path.basename(projectRoot);
  const outMd = options.out ? path.resolve(options.out) : null;

  const allFiles = crawlFiles(targetDir, filterType);

  // 1. Extract AST units
  const units = [];
  for (const file of allFiles) {
    const ext = path.extname(file).toLowerCase();
    let unit = null;
    if (ext === ".vue") unit = extractVueUnit(file, projectRoot);
    else if (ext === ".astro") unit = extractAstroUnit(file, projectRoot);
    else if (ext === ".ts" || ext === ".tsx" || ext === ".js" || ext === ".jsx") unit = extractTsUnit(file, projectRoot);
    else if (ext === ".go") unit = extractGoUnit(file, projectRoot);

    if (unit) units.push(unit);
  }

  // 2. Extract Git churn
  for (const u of units) {
    u.git = getGitChurn(u.filePath || u.absPath, projectRoot);
  }

  // 3. Build Inbound Degree Map
  const inboundMap = new Map();
  for (const u of units) {
    inboundMap.set(u.id, new Set());
  }

  for (const parent of units) {
    const refs = [...(parent.renderedChildren || []), ...(parent.composables || [])];
    for (const refName of refs) {
      for (const target of units) {
        if (target.id === refName || target.name.toLowerCase() === refName.toLowerCase()) {
          inboundMap.get(target.id)?.add(parent.id);
        }
      }
    }
  }

  // 4. Classify Slop & Score (0 - 100)
  const classifiedUnits = classifySlop(units, inboundMap);
  classifiedUnits.sort((a, b) => b.slopScore - a.slopScore);

  // 5. Generate Markdown Report
  const mdReport = generateMarkdownReport(projectName, targetDir, classifiedUnits);

  if (outMd) {
    fs.writeFileSync(outMd, mdReport, "utf-8");
    console.log(`\n✨ Generated Slop Radar report: ${outMd}`);
  }

  // 6. Print Terminal Summary
  printReport(classifiedUnits, projectName, outMd);
  return { units: classifiedUnits, mdReport, outMd };
}

function generateMarkdownReport(projectName, targetDir, units) {
  const critical = units.filter((u) => u.status === "critical");
  const warnings = units.filter((u) => u.status === "warning");
  const healthy = units.filter((u) => u.status === "healthy" || u.status === "stable");

  let md = `# ⚡ Slop Radar Scorecard — ${projectName}\n\n`;
  md += `Target: \`${targetDir}\`  \n`;
  md += `Scanned **${units.length} units** (${critical.length} critical hotspots, ${warnings.length} warnings, ${healthy.length} healthy).\n\n`;

  if (critical.length > 0) {
    md += `## 🔥 Critical Hotspots & God Units (Immediate Action)\n\n`;
    md += `| Unit | Score | LOC | Churn (6mo) | Cyclomatic | Archetype | Actionable Remediation |\n`;
    md += `| :--- | :---: | :---: | :---: | :---: | :--- | :--- |\n`;
    for (const u of critical) {
      const archetypes = u.flags.map((f) => `${f.icon} ${f.label}`).join(", ");
      const rec = u.recommendations[0] || "Refactor into smaller units.";
      md += `| \`${u.relPath}\` | **${u.slopScore}/100** | ${u.totalLoc} | ${u.git.commitCount} | ${u.cyclomatic} | ${archetypes} | ${rec} |\n`;
    }
    md += `\n`;
  }

  if (warnings.length > 0) {
    md += `## ⚠️ God Units, Coupling & Debt\n\n`;
    md += `| Unit | Score | LOC | Churn | Cyclomatic | Flags | Remediation |\n`;
    md += `| :--- | :---: | :---: | :---: | :---: | :--- | :--- |\n`;
    for (const u of warnings) {
      const flags = u.flags.map((f) => `${f.icon} ${f.label}`).join(", ");
      const rec = u.recommendations[0] || "Review dependencies.";
      md += `| \`${u.relPath}\` | ${u.slopScore}/100 | ${u.totalLoc} | ${u.git.commitCount} | ${u.cyclomatic} | ${flags} | ${rec} |\n`;
    }
    md += `\n`;
  }

  md += `## 📋 Top 15 Units Ranked by Slop Score\n\n`;
  md += `| Rank | Unit | Score | Category | LOC | Churn | Cyclomatic | Status |\n`;
  md += `| :---: | :--- | :---: | :--- | :---: | :---: | :---: | :---: |\n`;
  units.slice(0, 15).forEach((u, idx) => {
    const statusIcon = u.status === "critical" ? "🔴 Critical" : u.status === "warning" ? "🟠 Warning" : "🟢 Healthy";
    md += `| ${idx + 1} | \`${u.relPath}\` | ${u.slopScore} | ${u.tier || u.category} | ${u.totalLoc} | ${u.git.commitCount} | ${u.cyclomatic} | ${statusIcon} |\n`;
  });

  return md;
}

function printReport(units, projectName, outMd) {
  const critical = units.filter((u) => u.status === "critical");
  const warnings = units.filter((u) => u.status === "warning");

  console.log("\n========================================================");
  console.log(` ⚡ SLOP RADAR SCORECARD: ${projectName} (${units.length} units)`);
  console.log("========================================================");

  if (critical.length > 0) {
    console.log(`\n🔥 CRITICAL HOTSPOTS (${critical.length}):`);
    for (const u of critical.slice(0, 8)) {
      console.log(`  - [Score ${u.slopScore}/100] ${u.name} (${u.relPath})`);
      console.log(`    LOC: ${u.totalLoc} | Churn: ${u.git.commitCount} commits | Cyclomatic: ${u.cyclomatic}`);
      console.log(`    Flags: ${u.flags.map((f) => `${f.icon} ${f.label}`).join(", ")}`);
      console.log(`    Fix: ${u.recommendations[0]}\n`);
    }
  } else {
    console.log("\n✅ No critical hotspots detected!");
  }

  if (warnings.length > 0) {
    console.log(`⚠️ CODE DEBT & GOD UNITS (${warnings.length}):`);
    for (const u of warnings.slice(0, 6)) {
      console.log(`  - [Score ${u.slopScore}/100] ${u.name} (${u.relPath}) | LOC: ${u.totalLoc} | Cyclomatic: ${u.cyclomatic}`);
    }
  }

  if (!outMd) {
    console.log("\n💡 Tip: pass --out report.md to save the full ranked Markdown scorecard.");
  }
}

// Direct CLI invocation
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  const args = process.argv.slice(2);
  let targetDir = ".";
  let filterType = "all";
  let outMd = null;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--type" && args[i + 1]) {
      filterType = args[++i];
    } else if (args[i] === "--out" && args[i + 1]) {
      outMd = args[++i];
    } else if (!args[i].startsWith("--")) {
      targetDir = args[i];
    }
  }

  runSlopRadar({ dir: targetDir, filterType, out: outMd });
}
