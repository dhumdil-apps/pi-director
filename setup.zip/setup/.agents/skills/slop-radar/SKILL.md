---
name: slop-radar
description: Deterministic code quality scanner and hotspot ranking engine. Analyzes Frontend components (Vue SFC, Astro, TSX) and Backend modules (Go, TS/Node), measures git churn and cyclomatic complexity, flags god units, prop drillers, and dead code, and generates ranked Markdown scorecards for self-improvement feedback loops.
---

# Slop Radar (`slop-radar`)

A deterministic code-quality audit and ranking engine designed for **agent self-improvement feedback loops**.

It measures multi-dimensional health metrics across your codebase, detects architectural slop archetypes, ranks files by **Slop Score (0–100)**, and generates an actionable Markdown report (`.md`) or terminal scorecard.

---

## Quick Usage

Run the master scanner against any directory:

```bash
# Scan a directory and print the scorecard to terminal
node .agents/skills/slop-radar/scripts/scan.mjs tuto-fe/src

# Scan and output a ranked Markdown scorecard file
node .agents/skills/slop-radar/scripts/scan.mjs tuto-fe/src --out slop-scorecard.md

# Filter by type (vue | astro | ts | go)
node .agents/skills/slop-radar/scripts/scan.mjs tuto-be --type go --out be-audit.md
```

### Dedicated Runners

```bash
node .agents/skills/slop-radar/scripts/scan-vue.mjs <path-to-fe/src>
node .agents/skills/slop-radar/scripts/scan-astro.mjs <path-to-astro-project>
node .agents/skills/slop-radar/scripts/scan-ts.mjs <path-to-ts-project>
node .agents/skills/slop-radar/scripts/scan-go.mjs <path-to-be>
```

---

## Multi-Dimensional Metrics

Each file is inspected across 4 core vectors:

1. **Size & Structure**: Total LOC, script LOC, template LOC, function count.
2. **Git Churn (Last 6 Months)**: Frequency of commits touching the file, author velocity, change frequency.
3. **Complexity & Reactive Surface**:
   - **Vue**: `defineProps`, `defineEmits`, `use*` composables, Pinia stores, template directives (`v-if`, `v-for`, `@event`).
   - **Astro**: `Astro.props`, `Astro.slots`, client islands (`client:load`, `client:visible`).
   - **TypeScript**: Exported signatures, hooks (`use*`), JSX elements.
   - **Go**: Exported receiver methods, structs, interfaces, branching (`if`, `switch`, `select`, `err != nil`).
4. **Coupling & Graph Topology**: Inbound callers vs outbound dependencies.

---

## Slop Archetypes & Flags

| Archetype | Icon | Trigger Conditions | Remediation Playbook |
| :--- | :---: | :--- | :--- |
| **Critical Hotspot** | 🔥 | High Git Churn ($\ge 8$ commits) **AND** High Cyclomatic ($\ge 12$) | Split into smaller single-responsibility sub-modules to eliminate frequent edit collisions and merge friction. |
| **God Component / Module** | 🏛️ | Total LOC $> 320$ **AND** (Props $> 7$ OR Composables $\ge 5$ OR Cyclomatic $> 18$) | Apply [atomic-design](file:///Users/martin-peter.lakatos/Github/.agents/skills/atomic-design/SKILL.md) to decompose UI/logic into focused deep modules. |
| **Spaghetti Coupling** | 🪢 | $\ge 6$ imported composables (`use*`) or backend service dependencies | Introduce a domain facade or controller composable to encapsulate orchestration. |
| **Prop Drill Hub** | 🧱 | $\ge 9$ props **AND** $\ge 3$ rendered child components | Use slot composition (`<slot />`) or context/provide-inject instead of pass-through props. |
| **Shallow Module** | 🪶 | $\ge 8$ exports/props with $< 45$ LOC | Deepen the module's implementation or eliminate the unnecessary passthrough wrapper. |
| **Orphan Unit** | 👻 | 0 inbound callers/renderers (non-page/entrypoint) | Verify if obsolete or clean up dead code. |

---

## Cognitive Session Feedback Loop

During **Align** or **Spec** phases (see Session workflow in [AGENTS.md](file:///Users/martin-peter.lakatos/Github/AGENTS.md)):
1. Run `slop-radar` on the feature area being modified.
2. Include the ranked hotspot findings in the plan's `## Evidence` section.
3. Formulate decisions (`D{n}-slug`) and checklist items (`C{n}-slug`) targeting the highest-slop components.
